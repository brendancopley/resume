var app = angular.module("myApp", ['ngAnimate', 'ui.bootstrap']);
